export const BoldText = {
    state:{
        features: [],
    },
    reducers:{
        update: (state,payload)=>({...state, ...payload})
    }
}