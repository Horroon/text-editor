export const test = {
    state: {name:"Emumba"},
    reducers:{
        update:(state,payload)=>({name:"@emumba.com"})
    }
}